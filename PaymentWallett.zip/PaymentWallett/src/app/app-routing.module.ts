import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ViewComponent } from './view/view.component';
import { SignupComponent } from './signup/signup.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionsComponent } from './print-transactions/print-transactions.component';
const routes: Routes = 
[
{
    path:'login',
  component:HomeComponent
},
{
    path:'signup',
  component:SignupComponent
},
{
    path:'view',
  component:ViewComponent
},
{
  path:'create',
component:CreateAccountComponent
},
{path:'balance',
component:ShowBalanceComponent
},
{path:'deposit',
component:DepositComponent
},
{path:'withdraw',
component:WithdrawComponent
},
{path:'cashtransfer',
component:FundTransferComponent
},
{path:'transactions',
component:PrintTransactionsComponent
},

];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
